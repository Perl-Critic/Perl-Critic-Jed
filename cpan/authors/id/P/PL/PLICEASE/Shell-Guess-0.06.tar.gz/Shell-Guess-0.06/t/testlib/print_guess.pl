use strict;
use warnings;
use Shell::Guess;

print Shell::Guess->running_shell->name, "\n";
