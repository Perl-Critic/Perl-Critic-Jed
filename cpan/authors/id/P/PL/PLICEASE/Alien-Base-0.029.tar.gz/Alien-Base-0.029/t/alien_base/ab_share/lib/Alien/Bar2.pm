package Alien::Bar2;

use strict;
use warnings;
use parent qw( Alien::Base );

1;
