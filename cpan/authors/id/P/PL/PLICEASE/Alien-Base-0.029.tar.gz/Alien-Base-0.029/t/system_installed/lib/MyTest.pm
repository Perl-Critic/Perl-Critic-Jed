package MyTest;

use strict;
use warnings;

use parent 'Alien::Base';

1;

