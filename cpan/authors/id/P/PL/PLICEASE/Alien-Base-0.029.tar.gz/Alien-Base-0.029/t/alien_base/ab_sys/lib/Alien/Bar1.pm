package Alien::Bar1;

use strict;
use warnings;
use parent 'Alien::Base';

1;
